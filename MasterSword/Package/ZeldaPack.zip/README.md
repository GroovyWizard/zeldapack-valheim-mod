# ZeldaPack
Pack of TLOZ Items and Gear for Valheim. Note: This is my first mod for valheim so please report any issues to my github.

## Notes
Got all models from Models Resource website https://www.models-resource.com/ ive only ported them to valheim

## Installation (manual)
Thunderstore

## Features
1. Hylian Shield
2. Master Sword

## Changelog


## Known issues
You can find the github at:
https://github.com/GroovyWizard/zeldapack-valheim-mod
